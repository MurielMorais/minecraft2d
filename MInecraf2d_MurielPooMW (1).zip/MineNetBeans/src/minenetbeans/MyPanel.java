
package minenetbeans;
import javax.swing.*;
import java.awt.*;

public class MyPanel extends JPanel {

    private ImageIcon icon; // Armazena a imagem a ser exibida no painel

    public MyPanel(){
        icon = new ImageIcon("./src/Resource/steve.png"); // Carrega a imagem do arquivo "steve.png"
    }

    public MyPanel(ImageIcon icon){
        this.icon = icon; // Permite definir a imagem ao criar um objeto MyPanel
    }

    public void setIcon(ImageIcon icon) {
        this.icon = icon; // Permite alterar a imagem exibida no painel
        repaint(); // Redesenha o painel para exibir a nova imagem
    }

    @Override
    public void paint(Graphics g){
        // Desenha a imagem no painel, ajustando-a ao tamanho do painel
        g.drawImage(icon.getImage(), 0, 0, this.getWidth(), this.getHeight(), null);
    }
}
