
package minenetbeans;

import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class Janela extends JFrame implements KeyListener {
    private final int size = 400;
    private final int cols = 20;
    private final int rows = 20;

    private  final String Avatar = "./src/Resource/steve.png";
    private  final String azul = "./src/Resource/ceu.png";
    private  final String flor = "./src/Resource/flor.png";
    private  final String madeira = "./src/Resource/tronco.png";
    private  final String verde = "./src/Resource/folhas.png";
    private  final String terra = "./src/Resource/terra.png";

    private MyPanel myPanel[];

    private int[] tipoBloco;
    private  ImageIcon av;
    private  ImageIcon fundo;
    private  ImageIcon b1;
    private  ImageIcon b2;
    private  ImageIcon b3;
    private  ImageIcon b4;

private  int posAV;


   public Janela(){

       this.setLayout(new GridLayout(rows, cols));
       av = new ImageIcon(Avatar);
       fundo = new ImageIcon(azul);
       b1 = new ImageIcon(flor);
       b2 = new ImageIcon(madeira);
       b3 = new ImageIcon(verde);
       b4 = new ImageIcon(terra);

       tipoBloco = new int[size];
       myPanel = new MyPanel[size];
       for(int i =0; i<size;i++){
           myPanel[i]= new MyPanel(fundo);
           this.add(myPanel[i]);
       }

       posAV = 0;
       myPanel[0].setIcon(av);
       myPanel[20].setIcon(b2);
       
    tipoBloco[20] = 2;
    myPanel[20].setIcon(getIcon(20));
       

       this.addKeyListener(this);

       this.setTitle("MINECRAFT");
       this.setExtendedState(2);
       this.setVisible(true);

       this.setSize(200,200);
       this.setLocationRelativeTo(null);
       this.setDefaultCloseOperation(EXIT_ON_CLOSE);
    }

    private ImageIcon getIcon(int tipo){
           switch (tipoBloco[tipo]){
           case 1:
               return b1;
           case 2:
               return b2;
           case 3:
               return b3;
           case 4:
               return b4;
           default:
               return fundo;
       }
    }

    @Override
    public void keyTyped(KeyEvent e) {

    }

    @Override
    public void keyPressed(KeyEvent e) {

        // movimentações
        if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
            myPanel[posAV].setIcon(getIcon(posAV));
            posAV++;
            if (posAV > size-1) posAV = 0;
            myPanel[posAV].setIcon(av);
        }

        if (e.getKeyCode() == KeyEvent.VK_LEFT) {
            myPanel[posAV].setIcon(getIcon(posAV));
            posAV--;
            if (posAV < 0) posAV = size-1;
            myPanel[posAV].setIcon(av);
        }

        if (e.getKeyCode() == KeyEvent.VK_DOWN) {
            myPanel[posAV].setIcon(getIcon(posAV));
            posAV+=20;
            if (posAV > 399) posAV = posAV - 399;
            myPanel[posAV].setIcon(av);
        }

        if (e.getKeyCode() == KeyEvent.VK_UP) {
            myPanel[posAV].setIcon(getIcon(posAV));
            posAV-=20;
            if (posAV < 0) posAV = 399 - (Math.abs(posAV));
            myPanel[posAV].setIcon(av);
        }

        // construções
        if (e.getKeyCode() == KeyEvent.VK_1) {
            myPanel[posAV].setIcon(b1);
            tipoBloco[posAV] = 1;
            e.setKeyCode(KeyEvent.VK_RIGHT);
            keyPressed(e);
        }

        if (e.getKeyCode() == KeyEvent.VK_2) {
            myPanel[posAV].setIcon(b2);
            tipoBloco[posAV] = 2;
            e.setKeyCode(KeyEvent.VK_RIGHT);
            keyPressed(e);
        }

        if (e.getKeyCode() == KeyEvent.VK_3) {
            myPanel[posAV].setIcon(b3);
            tipoBloco[posAV] = 3;
            e.setKeyCode(KeyEvent.VK_RIGHT);
            keyPressed(e);
        }


        if (e.getKeyCode() == KeyEvent.VK_4) {
            myPanel[posAV].setIcon(b4);
            tipoBloco[posAV] = 4;
            e.setKeyCode(KeyEvent.VK_RIGHT);
            keyPressed(e);
        }

        if (e.getKeyCode() == KeyEvent.VK_SPACE) {
            myPanel[posAV].setIcon(fundo);
            tipoBloco[posAV] = 0;
            e.setKeyCode(KeyEvent.VK_RIGHT);
            keyPressed(e);
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {

    }
}

